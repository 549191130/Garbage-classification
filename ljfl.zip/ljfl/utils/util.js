var app;
function getRequestRet(kindid,keyword, pageNumber, pageSize, callback) {
  app = getApp();
  wx.showLoading({
    title: '数据加载中...',
  });
  wx.request({
    url: app.globaData.url +'/resources/pageResources',
    data: {
      kindid:kindid,
      conditions: keyword,
      pageSize: pageSize,  //返回数据的个数  
      pageNumber: pageNumber
    },
    method: 'post',
    header: { "Content-Type": "application/x-www-form-urlencoded" },
    success: function (res) {
      if (res.statusCode == 200) {
        callback(res.data);
      };
      wx.hideLoading();
    }
  })
}

function getRequestRet2(keyword, pageNumber, pageSize, callback) {
  app = getApp();
  wx.showLoading({
    title: '数据加载中...',
  });
  wx.request({
    url: app.globaData.url +'/resources/pageResources2',
    data: {
      conditions: keyword,
      pageSize: pageSize,  //返回数据的个数  
      pageNumber: pageNumber
    },
    method: 'post',
    header: { "Content-Type": "application/x-www-form-urlencoded" },
    success: function (res) {
      if (res.statusCode == 200) {
        callback(res.data);
      };
      wx.hideLoading();
    }
  })
}
// ajax get方式
function getAjaxRet(method,url, params, callback){
  wx.showToast({ title: '加载中', icon: 'loading', duration: 10000 });
  wx.request({
    method: method,
    url: url,
    data: params,
    header: method == 'get' ? { 'content-type': 'application/json' } : { "Content-Type": "application/x-www-form-urlencoded" },
    success: function (res) {
      wx.hideToast();
      if (res.statusCode == 200) {
        callback(res.data);
      };
    }
  });
}


module.exports = {
  getRequestRet: getRequestRet,
  getRequestRet2: getRequestRet2,
  getAjaxRet: getAjaxRet
}