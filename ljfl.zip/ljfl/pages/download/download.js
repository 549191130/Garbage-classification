// pages/about/about.js
const { $Message } = require('../../dist/base/index');
Page({

    /**
     * 页面的初始数据
     */
    data: {
        
    },
    saveImg:function(){
        wx.downloadFile({
            url: 'https://www.aipanysys.com/xiazai1.png',
            success: function (res) {
                wx.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success(result) {
                        $Message({
                            content: '保存成功!',
                            type: 'success'
                        });
                    },
                    fail: function (data) {
                        $Message({
                            content: '保存失败!',
                            type: 'error'
                        });
                    }
                })
            }
        })
    }, 
    saveImg2: function () {
        wx.downloadFile({
            url: 'https://www.aipanysys.com/xiazai2.png',
            success: function (res) {
                wx.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success(result) {
                        $Message({
                            content: '保存成功!',
                            type: 'success'
                        });
                    },
                    fail: function (data) {
                        $Message({
                            content: '保存失败!',
                            type: 'error'
                        });
                    }
                })
            }
        })
    },
    savePic:function(){
        wx.getSetting({
            success(res) {
                if (!res.authSetting['scope.writePhotosAlbum']) {
                    wx.authorize({
                        scope: 'scope.writePhotosAlbum',
                        success() {
                            wx.saveImageToPhotosAlbum({
                                filePath: '../../img/game.png',
                                success: function (res) {
                                    $Message({
                                        content: '保存成功!',
                                        type: 'success'
                                    });
                                },
                                fail: function (data) {
                                    debugger;
                                    $Message({
                                        content: '保存失败!',
                                        type: 'error'
                                    });
                                }
                            })
                        }
                    })
                }
            }
        });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})